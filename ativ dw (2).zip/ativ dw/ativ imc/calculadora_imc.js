function calcularIMC() {
    var name = document.getElementById('name').value;
    var weight = parseFloat(document.getElementById('weight').value);
    var height = parseFloat(document.getElementById('height').value);

    if (isNaN(weight) || isNaN(height) || height === 0) {
        document.getElementById('result').innerHTML = 'Por favor, insira valores válidos.';
        return;
    }

    var imc = weight / (height * height);

    var resultText = name + ' seu IMC é ' + imc.toFixed(2) + ' e você ';

    if (imc < 18.5) {
        resultText += 'é Abaixo do peso';
    } else if (imc < 24.9) {
        resultText += 'tem Peso normal';
    } else if (imc < 29.9) {
        resultText += 'é Sobrepeso';
    } else if (imc < 34.9) {
        resultText += 'tem Obesidade Grau I'
    } else if (imc < 39.9) {
        resultText += 'tem Obesidade Grau II'
    } else {
        resultText += 'tem Obesidade Grau III';
    }

    document.getElementById('result').innerHTML = resultText;
}
