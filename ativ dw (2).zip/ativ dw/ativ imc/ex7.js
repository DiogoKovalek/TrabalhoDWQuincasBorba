let n = 5;

let contador = 1;
let soma = 0;

while (contador <= n) {
    soma = soma + contador;
    contador = contador + 1;
}

console.log(soma);