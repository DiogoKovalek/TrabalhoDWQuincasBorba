function calculaMedia(a1, a2, a3) {
    let m = (a1 + a2 + a3) / 3;
    return m;
}

let n1 = 8;
let n2 = 7.5;
let n3 = 9.2;

let media = calculaMedia(n1, n2, n3);

console.log("A média é: ", media);