function calcularSalario(salarioInicial) {
    let salarioComAumento = salarioInicial * 1.15;
    let salarioFinal = salarioComAumento * 0.92;

    console.log("Salário Inicial: R$" + salarioInicial.toFixed(2));
    console.log("Salário com Aumento (15%): R$" + salarioComAumento.toFixed(2));
    console.log("Salário Final (desconto de 8% de impostos): R$" + salarioFinal.toFixed(2));
}

// Exemplo de uso
let salarioInicial = 3000;
calcularSalario(salarioInicial);