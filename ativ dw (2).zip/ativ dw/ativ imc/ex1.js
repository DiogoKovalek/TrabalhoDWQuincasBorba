let qtde_paes = 100;
let qtde_broa = 50;

let vendas = (qtde_paes * 0.5) + (qtde_broa * 1.5);
let lucro = vendas * 0.4;

console.log("o lucro foi de  ", lucro);